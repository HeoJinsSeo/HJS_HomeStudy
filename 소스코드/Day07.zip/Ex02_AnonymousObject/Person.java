package Day07.Ex02_AnonymousObject;

public class Person {
	
	String name;	// 이름
	int age;		// 나이
	
	void work() {
		System.out.println("일을 합니다");
	}

}
